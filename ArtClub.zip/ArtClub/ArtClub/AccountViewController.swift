//
//  AccountViewController.swift
//  ArtClub
//
//  Created by Владислав on 29.10.2021.
//

import UIKit

class AccountViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func GoBackToProfile(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is ProfileViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
