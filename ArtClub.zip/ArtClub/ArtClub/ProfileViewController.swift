//
//  ProfileViewController.swift
//  ArtClub
//
//  Created by Владислав on 29.10.2021.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func GoToAcc(_ sender: UIButton) {
        let newVC = storyboard?.instantiateViewController(identifier: "AccountViewController")
        navigationController?.pushViewController(newVC!, animated: true)
    }
}
