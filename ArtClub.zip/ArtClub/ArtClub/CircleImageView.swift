//
//  CircleImageView.swift
//  ArtClub
//
//  Created by Владислав on 27.10.2021.
//

import UIKit

class CircleImageView: UIViewController {
    @IBOutlet weak var circleImageView: CircleImageView!
    
}
